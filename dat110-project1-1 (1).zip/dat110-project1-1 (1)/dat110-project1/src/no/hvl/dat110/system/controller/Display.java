package no.hvl.dat110.system.controller;

import no.hvl.dat110.rpc.*;
import no.hvl.dat110.system.display.DisplayImpl;

public class Display extends RPCStub {

	private byte RPCID = 1;
	
	public Display() {
	
	}
	

	public void write(String message) {

		// TODO
		// implement marshalling, call and unmarshalling for write RPC method
		DisplayImpl display = new DisplayImpl();
		byte[] sender = RPCUtils.marshallString(RPCID, message);
		
	display.invoke(sender);
		String temp =RPCUtils.unmarshallString(sender);
		System.out.println("Grader" + temp);
	}
	
}

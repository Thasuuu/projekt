package no.hvl.dat110.messaging;
import static no.hvl.dat110.messaging.MessageConfig.SEGMENTSIZE;

import java.util.Arrays;

public class Message {

	private byte[] payload;

	public Message(byte[] payload) {
		if(payload.length <= SEGMENTSIZE) {
	this.payload = payload;// TODO: check for length within boundary
		}else {
			System.out.println("Invalid, because the message is too long");
		}
	
	
	}

	public Message() {
		super();
	}

	public byte[] getData() {
		return this.payload; 
	}

	public byte[] encapsulate() {
		int length = payload.length;
		
		byte[] encoded = new byte[SEGMENTSIZE];
		
		// TODO
		// encapulate/encode the payload of the message
		
		for(int j=length; j>0;j--) {;
			encoded[j] = payload [j-1];
		}
			
		encoded[0] = (byte) length;
		
		return encoded;
		
	}

	

	public void decapsulate(byte[] received) {

		// TODO
		// decapsulate data in received and put in payload
		
	  payload = new byte[received[0]];
	  for(int i =0; i< payload.length; i++) {
		  payload[i] = received[i+1];
	  }
	}
}
